
'use client';




export default function ThirdParagraph() {
  return (   
       
        <div className=" bg-white ">
             <div className="p-4   ">

          <span className="text-3xl font-bold ml-4">    Vaccination 
      <span className="font-Italic text-[#4B3A8F] "> handled with <br /> <i className="font-Italic font-light pl-4"> heart </i></span> </span>
            
           <p className="p-5"> 
            We know you’re busy juggling work, parenting, and everything in between. That’s why we are open 7 days a week, including weekends, to fit your hectic schedule. Our aim is to make every vaccination visit a smooth, positive experience for you and your kid, so every shot — from the first dose to boosters — feels like care, not a chore.

          </p>
               </div>               


             


      </div> 
    
    );
}